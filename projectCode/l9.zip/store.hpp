#ifndef STORE_HPP
#define STORE_HPP
#include "product.hpp"
#include <string>
#include <vector>
using std::string;
using std::vector;

class Store
{
private:
    vector<Product*> inventory;
    vector<Product*> shoppingCart;
public:
    void addProduct(Product* p);
    Product* getProductFromID(string);
    void productSearch(string);
    void addProductToCart(string);
    void checkOut();
};

#endif

