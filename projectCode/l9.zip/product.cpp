#include <iostream>
#include <string>
#include "product.hpp"
using std::string;


// Constructor
Product::Product(std::string id, std::string t, std::string d, double p, int qa)
{
    idCode = id;
    title = t;
    description = d;
    price = p;
    quantityAvailable = qa;
}

//Return Product title
string Product::getTitle()
{
    return title;
}

// Returns ID
string Product::getIdCode()
{
    return idCode;
}

// Return Description
string Product::getDescription()
{
    return description;
}

//Return Price
double Product::getPrice()
{
    return price;
}

// Return Quantity available
int Product::getQuantityAvailable()
{
    return quantityAvailable;
}

// Decrease Qty
void Product::decreaseQuantity()
{
    quantityAvailable--;
}
