#include <iostream>
#include <string>
#include "product.hpp"
#include "store.hpp"

using std::cout;
using std::cin;
using std::string;
using std::endl;



int main()
{

    //Create a store
    Store zMart;

    //CREATION OF PRODUCTS
    Product hammer("ABC123", "BIG HAMMER", "The most BEST", 9.99, 1);
    Product hammer2("ABC124", "No h ammer here", "The hammer money can buy", 89.99, 99);
    Product hammer3("ABC125", "ham bammer", "Great holiday gift", 4000.53, 6);


    Product screwDriver("SCD123", "Phillips screw driver", "Not a hammer", 13.99, 33);
    Product screwDriver2("SCD124", "Flat head screw driver", "Doesn't work on nails", 10.99, 3);
    Product screwDriver3("SCD125", "Multi-head screw driver", "So many choices", 16.99, 19);


    //Add products to store inventory
    zMart.addProduct(&hammer);
    zMart.addProduct(&hammer2);
    zMart.addProduct(&hammer3);

    zMart.addProduct(&screwDriver);
    zMart.addProduct(&screwDriver2);
    zMart.addProduct(&screwDriver3);

    printf("************************\n\n\n\n");


    //Browse store
    zMart.productSearch("Hammer");
    zMart.productSearch("screwdriver");

    //Add products to cart
    zMart.addProductToCart("ABC123");
    zMart.addProductToCart("ABC123");
    zMart.addProductToCart("SCD125");


    //Check OUT
    zMart.checkOut();

    return 0;
}
