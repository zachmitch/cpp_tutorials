#include <iostream>
#include <string>
#include <iomanip>
#include "store.hpp"
using std::string;




//Adds a product to our inventory
void Store::addProduct(Product* p)
{
    inventory.push_back(p);
}


//Searches through inventory and returns product if we carry that item
Product* Store::getProductFromID(string prod)
{

    int invSize = inventory.size();

    //iterate through each product and compare ID to search term
    for (int i = 0; i < invSize; i++)
    {
        if(prod == inventory[i]->getIdCode())
        {
            return inventory[i]; //If found return Product

        }
    }

    //If nothing found
    return NULL;
}



//Searches our product titles and descriptions to see if customer search
//term matches any items in our inventory
void Store::productSearch(string searchTerm)
{

    //Put search term in lower case
    for(int i = 0; i < searchTerm.size(); i++)
        searchTerm[i] = tolower(searchTerm[i]);


    for (int i = 0; i < inventory.size(); i++)
    {

        //Create copy of Title and description so we can later
        //put in lower case to match against search term
        string itemTitleLower = inventory[i]->getTitle();
        string itemDescLower = inventory[i]->getDescription();

        //Make title copy lowercase
        for (int j = 0; j < itemTitleLower.size(); j++)
        {
            itemTitleLower[j] = tolower(itemTitleLower[j]);
        }

        //Make description copy lowercase
        for (int j = 0; j < itemDescLower.size(); j++)
        {
            itemDescLower[j] = tolower(itemDescLower[j]);
        }


        //If find yields > -1 we know we have a match
        int foundInTitle = itemTitleLower.find(searchTerm);
        int foundInDescription = itemDescLower.find(searchTerm);

        //start by saying no match found
        bool foundItem = false;

        //But change that to a match if .find() shows > -1
        if ((foundInTitle >= 0) || (foundInDescription >= 0))
            foundItem = true;

        //If we get a match, print to the screen the item details
        if(foundItem)
        {
            std::cout << inventory[i]->getTitle() << std::endl;
            std::cout << "ID code: " << inventory[i]->getIdCode() << std::endl;
            std::cout << "price: $" << inventory[i]->getPrice() << std::endl;
            std::cout << inventory[i]->getDescription() << "\n" << std::endl;
        }

    }

}




//Adds a product to our member's cart
void Store::addProductToCart(string pID)
{

    Product * item = getProductFromID(pID);

    //If we don't have that item in our inventory
    if(item == NULL)
    {
        std::cout << "Product #" << pID << " not found." << std::endl;
        return;
    }

    //Add product to cart if inventory actually has quantity to be added
    if((item != NULL) && item->getQuantityAvailable() > 0)
    {
        shoppingCart.push_back(item);
    }
    else //If we are sold out of a product
    {
        std::cout << "Sorry, product #" << pID << " is currently out of stock." << std::endl;
    }


}

//Totals everything in cart and displays cost of everything

void Store::checkOut()
{


    if(shoppingCart.empty())
    {
        std::cout << "There are no items in the cart." << std::endl;
    }
    else
    {
        double subtotal = 0;  //used to hold subtotal before shipping cost

        int cartSize = shoppingCart.size();

        for(int i = 0; i < cartSize; i++)
        {
            //For each item in cart with quantity of 1 or more, print to screen details
            string prodID = shoppingCart[i]->getIdCode();
            if(getProductFromID(prodID)->getQuantityAvailable() > 0)
            {
                //print to screen details
                std::cout << getProductFromID(prodID)->getTitle() << " - $" << getProductFromID(prodID)->getPrice() << std::endl;

                //decrease inventory quantity and add cost to subtotal
                getProductFromID(prodID)->decreaseQuantity();
                subtotal += getProductFromID(prodID)->getPrice();

            }
            else
            {
                //if quantity dips below 1
                std::cout << "Sorry, product #" << prodID << ", '" << getProductFromID(prodID)->getTitle() << "', is no longer available." << std::endl;
            }
        }

        //output subtotal before shipping
        std::cout << "Subtotal: $" << subtotal << std::endl;


        // Tax is 7% of subtotal

        double tax = subtotal * .07;
        std::cout.precision(2); //So everything shows in 'dollars and cents'
        std::cout << "Tax: $" << std::fixed << tax << std::endl;
        std::cout << "Total: $" << subtotal + tax << std::endl;


        //Clear member cart after they checkout
        shoppingCart.clear();

    }



}



