#ifndef PRODUCT_HPP
#define PRODUCT_HPP
#include <string>
using std::string;

class Product
{
private:
    std::string idCode;
    std::string title;
    std::string description;
    double price;
    int quantityAvailable;
public:
    Product(string id, string t, string d, double p, int qa);
    string getIdCode();
    string getTitle();
    string getDescription();
    double getPrice();
    int getQuantityAvailable();
    void decreaseQuantity();
};

#endif

