#include <iostream>
#include <stdio.h>
#include <string>
#include "bankAccount.cpp"

using std::endl;
using std::cout;
using std::cin;
using std::string;



int main() {

    BankAcct Zach("Zach", "123", 1004.45);
    //instantiation

    cout << Zach.getCustomerName() << endl;
    cout << Zach.getCustomerID() << endl;
    cout << Zach.getBalance() << endl;

    Zach.withdraw(100);
    cout << Zach.getBalance() << endl;  // 904.45
    Zach.deposit(1000.01);
    cout << Zach.getBalance() << endl;  // 1904.46





    return 0;
}




