#ifndef BANKACCT_HPP
#define BANKACCT_HPP
#include <string>
using std::string;


class BankAcct{
    private:
        string customerName;  // username
        string customerID;   // internal id
        double balance;  // money in acct

    public:
        BankAcct(std::string name, string id, double bal){
            customerName = name;
            customerID = id;
            balance = bal;
        }
        string bankName;
        string getCustomerName();
        string getCustomerID();
        double getBalance();
        void withdraw(double);
        void deposit(double);
};

#endif // BANKACCT_HPP
