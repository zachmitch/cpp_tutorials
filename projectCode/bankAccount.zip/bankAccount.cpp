#include <iostream>
#include <stdio.h>
#include <string>
#include "bankAccount.hpp"

using std::endl;
using std::cout;
using std::cin;
using std::string;



string BankAcct::getCustomerName() {
    return customerName;
}

string BankAcct::getCustomerID(){
    return customerID;
}
double BankAcct::getBalance(){
    return balance;
}
void BankAcct::withdraw(double amount){
    balance -= amount;
}
void BankAcct::deposit(double amount) {
    balance += amount;
}
