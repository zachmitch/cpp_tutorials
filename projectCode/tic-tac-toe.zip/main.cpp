#include <iostream>
#include <string>
#include "TicTacToe.hpp"
#include "Board.hpp"


void runTicTacToe();

int main()
{

	runTicTacToe();

	return 0;
}


/*******************RUNTICTACTOE()*********************
 This function creates and runs a new TicTacToe game.

 It prompts player one whether they're an 'x' or an 'o',
 and keeps the fun going until the user wants to quit.
 *******************************************************/


void runTicTacToe()
{

    bool playAgain = false;  //Later we ask the user if they want to play again


    //Executes the TicTacToe game as long as the players want to play

    do{
        //Introductory welcome
        std::cout << "Welcome to the classic game of TicTacToe!" << std::endl;
        std::cout << "Player 1, would you like to be X's or O's?  Choose 'x' or 'o': " << std::endl;
        char p1;
        std::cin >> p1;  //Player 1 choses whether they're an x or o
        std::cout << "\nFantastic!  Let's begin.\n" << std::endl;

        TicTacToe newGame(p1);  //Create a new game passing player1's choice of x or o
        newGame.play();  //play loops until we get a result

        //Who wants to play again?!? amirite
        std::cout << "Want to play again? ('Y' or 'N'): " << std::endl;

        //From here on is the decision structure of what
        //to do if user wants to play again or not
        char response;  // yes or no to playing again
        std::cin >> response;

        if ((response == 'y') || (response == 'Y'))
            playAgain = true;
        else
            playAgain = false;

    } while(playAgain);
}
