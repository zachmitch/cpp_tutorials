#include "Board.hpp"
#include <iostream>

/******************DEFAULT CONSTRUCTOR*********************
Creates a 3x3 gameboard that is filled with placeholder '.'
 in each cell.
 ********************************************************/


Board::Board()
{
	for(int i=0; i<3; i++)
	{	for(int j=0; j<3; j++)
		{
			gameBoard[i][j] = '.';
		}
	}
}

/******************PRINT*********************
Prints to the screen, the current state of the gameboard,
 including a 0-2 guide to show user row/column of choice
 ********************************************************/

void Board::print()
{
	std::cout << "  0 1 2\n"; //columns across top

	for(int i=0; i<3; i++)
	{
		std::cout << i << " "; //rows along the side

		for(int j=0; j<3; j++)
		{
			std::cout << gameBoard[i][j] << " ";
		}

		std::cout << "\n";
	}
}

/******************MAKE MOVE*********************
Takes in whether who's turn it is and where they want to mark.
 If the spot is already taken, it will let us know by returning false.
 ********************************************************/


bool Board::makeMove(int x, int y, bool p1)
{

	//If p1 == true, set mark to X, else O
	char mark = p1 ? 'X': 'O';

	if(gameBoard[x][y] == '.')
	{
		gameBoard[x][y] = mark;

		return true;  // Move was made
	}
	else
	{
		std::cout << "That square is already taken." << std::endl;
		return false;  // Move could not be made
	}
}


/******************gameState*********************
 If there are 3 in a row, it outputs a win, whether it be x or o.
 If everything is filled up and no 3 in a row, its a draw.  Otherwise,
 game is unfinished
 ********************************************************/


int Board::gameState(bool p1)
{

	//If p1 == true, set mark to X, else O
	char mark = p1 ? 'X': 'O';

	GameResult result; //Holds the outcome of each turn

    //First check to see if we have a winner (all the different ways to win)
	if( 	(mark == gameBoard[0][0] && mark == gameBoard[0][1] && mark == gameBoard[0][2]) ||
				(mark == gameBoard[1][0] && mark == gameBoard[1][1] && mark == gameBoard[1][2]) ||
				(mark == gameBoard[2][0] && mark == gameBoard[2][1] && mark == gameBoard[2][2]) ||
				(mark == gameBoard[0][0] && mark == gameBoard[1][0] && mark == gameBoard[2][0]) ||
				(mark == gameBoard[0][1] && mark == gameBoard[1][1] && mark == gameBoard[2][1]) ||
				(mark == gameBoard[0][2] && mark == gameBoard[1][2] && mark == gameBoard[2][2]) ||
				(mark == gameBoard[0][0] && mark == gameBoard[1][1] && mark == gameBoard[2][2]) ||
				(mark == gameBoard[0][2] && mark == gameBoard[1][1] && mark == gameBoard[2][0]))
	{

		//Whoever's turn it is wont the game, return that
		return result = p1 ? X_WON:O_WON;

	}

	//Now we must check to see if the game is ongoing, or finished with a draw

    //start off by saying we have a draw
	bool draw = true;

    //cycle through each cell and if you find a '.',
    //that means the game is ongoing, and no draw
	for(int i = 0; i < 3; i++)
	{	for(int j = 0; j < 3; j++)
		{ if(gameBoard[i][j] == '.')
			draw = false;
		}
	}

	//If draw is still true, we have a tie...otherwise game is ongoing
	return result = draw ? DRAW:UNFINISHED;

}
