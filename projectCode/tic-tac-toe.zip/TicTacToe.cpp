#include <iostream>
#include "TicTacToe.hpp"
#include <string>



/******************CONSTRUCTOR*********************
 1st player is instructed to choose either 'x' or 'o' and that
 triggers a bool (player1Turn) to trigger either 'x' or 'o',
 and this bool flips between true and false, choosing player 1
 and player 2
 ********************************************************/

TicTacToe::TicTacToe(char t)
{

    if((t=='x') || (t=='X'))
        player1Turn = true;  //player 1 will be X
    else
        player1Turn = false; // player 1 will be O
}


/******************PLAY****************************
 This function is the core of the program.  It executes everything
 that needs to be done each turn (marking the board, switching players, etc)
 until we either have a winner or a draw.
 **************************************************/

void TicTacToe::play()
{
    do{ //this do-while says to keep looping while the game result is unfinished

        std::string playerTitle;  // "Player X" or "Player O"
        int row; // row # of 2D array
        int col; // col # of 2D array
        bool isOpen;  // Is the spot available to be chosen?


        theGame.print();  // Print the board in it's current state


        //Who's turn is it?  This is for screen output
				playerTitle = player1Turn ? "Player X" : "Player O";


        do{ //this do-while executes until the player has chosen a legal move

            std::cout << "\n" << playerTitle << ": please enter your move (row# col#)" << std::endl;

            std::cin >> row;
            std::cin >> col;
						std::cout << std::endl; //Extra space for visuals

            //Checks if spot is available to be chosen
            isOpen = theGame.makeMove(row,col,player1Turn);

      	} while(!isOpen); //If spot unavailable, choose again


        //switches turns between player 1 and player 2
  			player1Turn = !player1Turn;

      //in the while we check !player1Turn, to check the player that just made a move
    } while(theGame.gameState(!player1Turn) == 3); //continue game while unfinished (enum 3)


    theGame.print();  //After game is finished print the board to show final state

    //Output to user what the final outcome was, by checking gamestate enum
    switch(theGame.gameState(!player1Turn))
    {
        case 0:
            std::cout << "\nX WINS THE GAME!" << std::endl;
            break;
        case 1:
            std::cout << "\nO WINS THE GAME!" << std::endl;
            break;
        case 2:
            std::cout << "\nDraw...no winner." << std::endl;
            break;
    }

}
