#ifndef TICTACTOE_HPP
#define TICTACTOE_HPP
#include <iostream>
#include "Board.hpp"

class TicTacToe
{
	private:
	Board theGame;
	bool player1Turn;

	public:
	TicTacToe(char t);
	void play();

};

#endif
