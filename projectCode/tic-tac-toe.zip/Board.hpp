#ifndef BOARD_HPP
#define BOARD_HPP

class Board
{
	private:
	char gameBoard[3][3];

	public:
	Board();
	bool makeMove(int x, int y, bool p1);
	int gameState(bool p1);
	void print();
	enum GameResult
	{ X_WON, O_WON, DRAW, UNFINISHED};
};



#endif
