#include <iostream>
#include <string>
#include <math.h>
#include "plot.hpp"

using std::string;
using std::cout;
using std::cin;
using std::endl;



void Plot::addPoint(Point * pt){
    this->pointList[plotPoints] = pt;
    plotPoints++;
}
void Plot::listPoints() {

    for(int i = 0; i < plotPoints; i++){
        cout << "x: " << pointList[i]->getX() << " y: " << pointList[i]->getY() << endl;
    }

}

