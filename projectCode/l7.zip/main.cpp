#include <iostream>
#include <string>
#include "point.cpp"
#include "plot.cpp"

using std::string;
using std::cout;
using std::cin;
using std::endl;



int main() {

    Point knownXy(1,1);
    Point somePoint;


    return 0;
}
