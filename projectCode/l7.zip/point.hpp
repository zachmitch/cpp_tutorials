#ifndef POINT_HPP
#define POINT_HPP

class Point{
    private:
        double x;
        double y;

    public:
        //Constructor
        Point(double x, double y){
            this->x = x;
            this->y = y;
        }
        //Default Constructor
        Point(){
            this->x = 0;
            this->y = 0;
        }
};


#endif // LINE_HPP

