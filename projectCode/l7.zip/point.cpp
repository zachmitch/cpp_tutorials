#include <iostream>
#include <string>
#include <math.h>
#include "point.hpp"

using std::string;
using std::cout;
using std::cin;
using std::endl;

double Point::getX() {

    return x;
}
double Point::getY(){
    return y;
}
double Point::distanceTo(Point * pt) {

    double dist = sqrt(pow((this->x - pt->x),2) + pow((this->y - pt->y),2));
    return dist;
}
