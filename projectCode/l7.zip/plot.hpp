#ifndef PLOT_HPP
#define PLOT_HPP
#include "point.hpp"

class Plot{

private:
    std::string plotname;
    Point * pointList[10];
    int plotPoints;

public:
    Plot(){
        this->plotname = "Default";
        this->plotPoints = 0;
        for(int i= 0; i< 10; i++){
            this->pointList[i] = NULL;
        }
    }

    ~Plot(){

        for(int i = 0; i < 10; i++){
            delete pointList[i];
            pointList[i] = NULL;
        }

    }
    void addPoint(Point *);
    void listPoints();


};




#endif // PLOT_HPP
